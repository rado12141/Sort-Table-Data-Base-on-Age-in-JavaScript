var names = [
	{"firstname":"John", "lastname":"Smith", "age":"24"},
	{"firstname":"Claire", "lastname":"Temple", "age":"18"},
	{"firstname":"Steve", "lastname":"Anderson", "age":"39"},
	{"firstname":"Paul", "lastname":"Spear", "age":"28"},
	{"firstname":"Paula", "lastname":"Hope", "age":"20"},
];
	
	
function displayTable(){
	var data = "";
	if(names.length > 0){
		for(var i=0; i < names.length; i++){
			data += "<tr>";
			data += "<td>"+names[i].firstname +"</td>";
			data += "<td>"+names[i].lastname+"</td>";
			data += "<td>"+names[i].age+"</td>";
			data += "</tr>";
		}
	}
	
	document.getElementById('result').innerHTML = data;
}


function filterAscending(){
	if(names.length > 0){
		var sortArray = names;
		
		sortArray.sort(function(a,b){
			if(a.age < b.age){
				return -1;
			}
			
			if(a.age > b.age){
				return 1;
			}
		
			return 0;
		});
		
		
		var data = "";
		
		if(names.length > 0){
			for(var i=0; i < names.length; i++){
				data += "<tr>";
				data += "<td>"+names[i].firstname +"</td>";
				data += "<td>"+names[i].lastname+"</td>";
				data += "<td>"+names[i].age+"</td>";
				data += "</tr>";
			}
		}
		
		document.getElementById('result').innerHTML = data;
		
	}
	
}

function filterDescending(){
	if(names.length > 0){
		var sortArray = names;
		
		sortArray.sort(function(a,b){
			if(a.age > b.age){
				return -1;
			}
			
			else if(a.age < b.age){
				return 1;
			}else{
				return 0;
			}
		
			
		});
		
		
		var data = "";
		
		if(names.length > 0){
			for(var i=0; i < names.length; i++){
				data += "<tr>";
				data += "<td>"+names[i].firstname +"</td>";
				data += "<td>"+names[i].lastname+"</td>";
				data += "<td>"+names[i].age+"</td>";
				data += "</tr>";
			}
		}
		
		document.getElementById('result').innerHTML = data;
		
	}
}